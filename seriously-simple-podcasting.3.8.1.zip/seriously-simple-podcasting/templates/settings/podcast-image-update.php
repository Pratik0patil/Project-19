<?php
/**
 * @var string $series_img_title
 * @var string $upload_image
 * */
?>
<tr class="form-field term-upload-wrap">
	<th scope="row"><label><?php echo esc_html( $series_img_title ) ?></label></th>
	<td><?php echo $upload_image ?></td>
</tr>
