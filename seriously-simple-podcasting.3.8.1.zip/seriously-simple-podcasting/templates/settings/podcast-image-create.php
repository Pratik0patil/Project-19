<?php
/**
 * @var string $series_img_title
 * @var string $upload_image
 * */
?>
<div class="form-field term-upload-wrap">
	<label><?php echo esc_html( $series_img_title ) ?></label>

	<?php echo $upload_image ?>
</div>

