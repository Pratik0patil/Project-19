<div class="ssp-onboarding__skip">
	<a href="<?php echo admin_url('edit.php?post_type=' . SSP_CPT_PODCAST . '&page=podcast_settings') ?>">
		<?php _e( 'Skip Setup', 'seriously-simple-podcasting' ); ?>
	</a>
</div>
