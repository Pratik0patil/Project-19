<?php

namespace SeriouslySimplePodcasting\ShortCodes;

interface Shortcode {
	public function shortcode( $params );
}
