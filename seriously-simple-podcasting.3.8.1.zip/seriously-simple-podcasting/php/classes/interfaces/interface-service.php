<?php

namespace SeriouslySimplePodcasting\Interfaces;

interface Service {
}
