<?php

namespace SeriouslySimplePodcasting\Interfaces;

interface Singleton {

	public static function instance();
}
