<?php
/**
 * @see \SeriouslySimplePodcasting\Handlers\Settings_Handler::get_integrations_settings()
 * */
return array(
	'title'  => __( 'Integrations', 'seriously-simple-podcasting' ),
	'items'  => array(),
	'fields' => array(),
);
