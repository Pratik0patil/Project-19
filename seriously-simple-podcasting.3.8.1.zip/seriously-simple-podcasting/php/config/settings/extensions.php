<?php

return array(
	'title'               => __( 'Extensions', 'seriously-simple-podcasting' ),
	'description'         => __( 'These extensions add functionality to your Seriously Simple Podcasting powered podcast.', 'seriously-simple-podcasting' ),
	'fields'              => array(),
	'disable_save_button' => true,
);
