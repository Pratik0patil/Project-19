<?php

/**
 * @see Settings_Controller::render_external_import_form()
 * */
return array(
	'title'       => __( 'Import', 'seriously-simple-podcasting' ),
	'description' => '',
	'fields'      => array(
	),
);
